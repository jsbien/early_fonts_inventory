﻿﻿[PL] ---------------------------------------------------------------------------
Tytuł: 
Farrago civilium actionum ad formam Juris Maydeburgensis pro consuetudine in Regno Polo[niae] iampride[m] recepta ac observata per recognitionem denique prioris authoris auctior et [...] limatior [...] Tota farrago quatuor absolvitur partibus

Główny plik publikacji: 
index.djvu

Prosimy rozpocząć przeglądanie publikacji od jej pliku głównego.

W kwestii dalszego wykorzystania pobranej publikacji należy kontaktować się
z biblioteką cyfrową, z której plik został pobrany. Na stronach WWW z opisem 
tej publikacji powinny znajdować się dokładniejsze informacje 
dotyczące praw autorskich.

Ten plik zakodowany jest w standardzie UTF-8.
[EN] ---------------------------------------------------------------------------
Title:
Farrago civilium actionum ad formam Juris Maydeburgensis pro consuetudine in Regno Polo[niae] iampride[m] recepta ac observata per recognitionem denique prioris authoris auctior et [...] limatior [...] Tota farrago quatuor absolvitur partibus

Publication main file:
index.djvu

Please start viewing the publication from its main file.

For further reuse of this publication please contact the digtial library 
from which the file was downloaded. On the website with the publication 
description you should be able to find more detailed information regarding 
the intellectual property rights.

This file is encoded in UTF-8 standard.
 ------------------------------------------------------------------------------
Generated automatically by dLibra Digital Library Framework.
- See http://dlibra.psnc.pl/ for more details.

